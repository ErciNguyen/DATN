[![Semantic Release](https://github.com/SSI-Securities-Corporation/python-fctrading/actions/workflows/publish.yaml/badge.svg)](https://github.com/SSI-Securities-Corporation/python-fctrading/actions/workflows/publish.yaml)

# Installation
#### From tar ball (most stable)
``` python
pip install ssi-fctrading
```
#### Install behind proxy
```python
pip install --trusted-host pypi.org --trusted-host
files.pythonhosted.org --proxy=http://<username>:<password>@<host>:<port> dist/ssi_fctrading-2.3.0.tar.gz
```

#### Pypi
``` python
pip install ssi_fctrading
```
